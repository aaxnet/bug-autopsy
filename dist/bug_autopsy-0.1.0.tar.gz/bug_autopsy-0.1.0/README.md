# 🔬 Bug Autopsy

> Turn raw Python tracebacks into actionable insights — instantly.

Bug Autopsy is a lightweight Python CLI tool that analyses logs, stack traces, and error outputs, then provides structured diagnostics including probable root cause, a human-readable explanation, and suggested fixes.

No external dependencies. No cloud. Just answers.

---

## Features

- **20+ error patterns** detected out of the box (ModuleNotFoundError, KeyError, TypeError, and many more)
- **Environment inference** — automatically detects Flask, FastAPI, Django, pytest, SQLAlchemy, and more
- **Stack frame parsing** — pinpoints the exact file and line that caused the error
- **Confidence scoring** — heuristic-based scoring tells you how certain the diagnosis is
- **Markdown reports** — generate shareable `.md` autopsy reports with one flag
- **Zero dependencies** — core runs on the Python standard library (Python ≥ 3.9)
- **Cross-platform** — works on Windows, Linux, and macOS

---

## Installation

### From source (recommended during development)

```bash
git clone https://github.com/yourname/bug-autopsy.git
cd bug-autopsy
pip install -e ".[dev]"
```

### Once published to PyPI

```bash
pip install bug-autopsy
```

---

## Usage

### Analyse a log file

```bash
autopsy --file path/to/error.log
```

### Analyse inline text

```bash
autopsy --text "ModuleNotFoundError: No module named 'requests'"
```

### Pipe from another command

```bash
python my_script.py 2>&1 | autopsy
```

### Generate a Markdown report

```bash
autopsy --file crash.log --report autopsy_report.md
```

### Suppress console output (report only)

```bash
autopsy --file crash.log --report report.md --quiet
```

### Disable colour (for CI environments)

```bash
autopsy --file crash.log --no-color
```

---

## Example Output

```
╔══════════════════════════════════════════╗
║         🔬  B U G   A U T O P S Y       ║
╚══════════════════════════════════════════╝
  2 error(s) detected

┌─ [1] KeyError
│  Message  : KeyError: 'url'
│  Context  : Database / ORM
│  Confidence: [███████████████████░] 95%
│
│  🧠 Explanation
│     The key 'url' was not found in the dictionary. The data structure does
│     not contain this key at the time of access.
│
│  📍 Stack Trace Locations
│     • startup()  →  /srv/api/main.py:47
│     • fallback_connect()  →  /srv/api/db.py:18
│
│  🔧 Recommended Fixes
│   1. Use `.get()` with a default: `value = d.get('url', default_value)`
│   2. Check for typos in the key name — keys are case-sensitive.
│   3. Verify that the key is populated before access.
│   4. Add a guard: `if 'url' in d:` before accessing.
└────────────────────────────────────────────────────────────
```

---

## Detected Error Types

| Error Type | Description |
|---|---|
| `ModuleNotFoundError` | Missing package or wrong virtual environment |
| `ImportError` | Bad import name, circular import, or broken install |
| `KeyError` | Dictionary key not present |
| `IndexError` | List index out of range |
| `TypeError` | Wrong type passed to a function or operation |
| `NameError` | Variable used before assignment |
| `AssertionError` | Failed assertion / invariant |
| `PermissionError` | OS file-system permission denied |
| `TimeoutError` | Network or I/O operation timed out |
| `AttributeError` | Attribute not found on an object |
| `ZeroDivisionError` | Division by zero |
| `FileNotFoundError` | File or directory does not exist |
| `RecursionError` | Maximum recursion depth exceeded |
| `UnicodeDecodeError` | Encoding mismatch when reading bytes |
| `ValueError` | Correct type but invalid value |
| `MemoryError` | Out of memory |
| `RuntimeError` | General runtime failure |
| `OSError` | OS-level error |
| `StopIteration` | Exhausted iterator used outside generator context |

---

## Project Structure

```
bug-autopsy/
├── autopsy/
│   ├── __init__.py     # Package metadata
│   ├── analyzer.py     # Core parsing, detection & classification
│   ├── cli.py          # Command-line interface
│   └── report.py       # Markdown report generation
├── examples/
│   ├── module_not_found.log
│   ├── multi_error.log
│   ├── flask_error.log
│   └── sample_report.md
├── tests/
│   ├── test_analyzer.py
│   └── test_report.py
├── pyproject.toml
└── README.md
```

---

## Running Tests

```bash
# All tests
pytest

# With coverage
pytest --cov=autopsy --cov-report=term-missing
```

All 39 tests pass on Python 3.9–3.12.

---

## Python API

Bug Autopsy can also be used programmatically:

```python
from autopsy.analyzer import analyze
from autopsy import report as report_mod

log_text = open("crash.log").read()
results = analyze(log_text)

for r in results:
    print(f"{r.error_type} — {r.confidence:.0%} confidence")
    print(r.explanation)
    for fix in r.fixes:
        print(f"  • {fix}")

# Generate a Markdown report
md = report_mod.generate(results, source_label="crash.log")
report_mod.save(md, "autopsy_report.md")
```

---

## Future Enhancements

- LLM-powered explanations (AI mode)
- GitHub issue analyser
- Auto-reproduction sandbox
- Auto-fix / patch suggestion system
- Web UI dashboard (FastAPI)

---

## License

MIT — see `LICENSE`.
